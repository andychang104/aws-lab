<?php

  echo gethostname();

?>
